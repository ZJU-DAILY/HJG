/*entry.h
  this file defines class Entry*/
#ifndef __Entry 
#define __Entry
//------------------------------------------------------------
#include "../func/gendef.h"
//------------------------------------------------------------
class RTNode;
class RTree;
struct Linkable;
//------------------------------------------------------------
class Entry 
{
public:
    RTree *my_tree;                     // pointer to my R-tree
	  //Tips: for classes that inherit this one, overload this variable.  i.e.
	  //define a my_tree which point to another type (say MVRTree).
    RTNode *son_ptr;                    // pointer to son if in main mem.
	  //overload this variable in case of inheritance
    
	float *bounces;                     // pointer to box
	int son;

	int dimension;                      // dimension of the box
	int level;                     
	  //note level field of entry is not stored in the disk.  its main usage
	  //is in the insertion function.  so before inserting any entry, remember 
	  //to set this field.

	  //================functions=======================
	Entry();
	
	Entry(int dimension, RTree *rt);

    ~Entry();

	void del_son();

	void init_entry(int _dimension, RTree *_rt);

    SECTION section(float *mbr);        // tests, if mbr intersects the box

    RTNode *get_son();                  // returns pointer to the son,
                                        // loads son if necessary

	Linkable *gen_Linkable();

	void set_from_Linkable(Linkable *link);

    bool section_circle(float *center, float radius);

    void read_from_buffer(char *buffer);// reads data from buffer

    void write_to_buffer(char *buffer); // writes data to buffer

    int get_size();                     // returns amount of needed buffer space

    virtual Entry & operator = (Entry &_d);

	bool operator == (Entry &_d);
};

#endif