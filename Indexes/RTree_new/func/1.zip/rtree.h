/* rtree.h
   this file defines the class RTree*/

#ifndef __RTREE
#define __RTREE
//------------------------------------------------------------
#include "../func/gendef.h"
//------------------------------------------------------------
class LinList;
class SortedLinList;
class Cache;
class RTNode;
class Entry;
//------------------------------------------------------------
class RTree : public Cacheable
{
public:
    int root;                            // block # of root node
    RTNode *root_ptr;                    // root-node
    bool root_is_data;                   // TRUE, if root is a data page
    int dimension;                       // dimension of the data's

    int num_of_data;	                 // # of stored data
    int num_of_dnodes;	                 // # of stored data pages
    int num_of_inodes;	                 // # of stored directory pages

    bool *re_level;                      // if re_level[i] is TRUE,
                                         // there was a reinsert on level i
    LinList *re_data_cands;               // data entries to reinsert
	LinList *deletelist;

	//***********note***********
    //BlockFile *file;	                 // storage manager for harddisc blocks
    //Cache *cache;                        // LRU cache for managing blocks in memory
	  //note that we no longer need these two variable since we can inherit it from Cacheable
	//*************************

	  //==========================================================
	RTree(char *fname, int _b_length, Cache* c, int _dimension);
    RTree(char *fname, Cache* c);
    RTree(char *inpname, char *fname, int _blength, Cache* c, int _dimension);
    ~RTree();

    void load_root();                    // loads root_node into memory
    
	void read_header(char *buffer);      // reads Rtree header
    
	void write_header(char *buffer);     // writes Rtree header
    
	int get_num()                        // returns # of stored data
		{ return num_of_data; }

    void insert(Entry *d);               // inserts new data into tree
	
	bool delete_entry(Entry *d);

    void rangeQuery(float *mbr, SortedLinList *res);

	bool FindLeaf(Entry *e);
};

#endif // __RTREE
