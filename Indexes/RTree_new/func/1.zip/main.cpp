#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "./rtree/rtree.h"
#include "./rtree/rtnode.h"
#include "./rtree/entry.h"
#include "./blockfile/blk_file.h"
#include "./linlist/linlist.h"
#include "./rtree/rtree_cmd.h"


void create_tree(char *inpfile, char* rfile, int blksize)
{
	RTree *rt;
	rt = new RTree(inpfile, rfile, blksize, NULL, 2);
	delete rt;
}

void print_node(RTNode *n)
{
	int i;
	RTNode *succ;

	printf("RTNode %d, level %d:\n", n->block, n->level);
    for (i=0; i<n->num_entries; i++)
	{
        printf("%f %f %f %f\n",
            n->entries[i].bounces[0],
            n->entries[i].bounces[1],
            n->entries[i].bounces[2],
            n->entries[i].bounces[3]);

		if (n->level>0)
		{
		    succ = n->entries[i].get_son();
		    print_node(succ);
		}
	}
}

void print_tree(char *fname)
{
    RTree *rt;
    rt = new RTree(fname, NULL);
    rt->load_root();
	Entry *e;
    e=new Entry();
    int entrysize=e->get_size();
	int nodesize=rt->file->get_blocklength();
	int capacity=(int)(nodesize-BFHEAD_LENGTH)/entrysize;
    printf("Printing rtree with the filename %s\n",fname);
	printf("Each node has the size %d\n",nodesize);
	printf("Each each has the size %d\n",entrysize);
	printf("Each node has %d entries\n",capacity-2);

    //print_node(rt->root_ptr);
	delete rt;
}

void range_test()
{
	RTree *rt;
	SortedLinList *res;
	float* mbr;

	rt = new RTree("gr_10_1.rtr", NULL);

	mbr = new float[4];
	mbr[0] = 400000;
	mbr[1] = 405000;
	mbr[2] = 780000;
	mbr[3] = 785000;

	res = new SortedLinList();

	rt->rangeQuery(mbr, res);
	res->print();

	delete [] mbr;
	delete res;

	delete rt;
}

void block_size(char* name)
{
	RTree *rt;

	rt = new RTree(name, NULL);

    printf("blocksize: %d\n", rt->file->get_blocklength());
	delete rt;
}

void testread()
{
	BlockFile *f;
	f=new BlockFile("1.dat",0);
	char buf[256];
	f->read_block(buf,0);
	int i;
	for (i=0;i<256;i++)
		printf("%d\n",buf[i]);
	return;
	delete f;
}

void testwrite()
{
	BlockFile *f;
	f=new BlockFile("1.dat",256);
	char buf[256];
	int i;
	for (i=0;i<256;i++)
	{
		buf[i]=(char)i;
	}
	int b;
	b=f->append_block(buf);
	printf("%d\n",b);
	delete f;
}

void test(RTree *rt)
{
	float x0,y0,x1,y1;
	int id;
	Entry *d;
	FILE *fp;
	if((fp=fopen("1.txt","r"))==NULL)
    {
      error("Cannot open R-Tree text file", true);
    }
    else
    {
	  int i=0;
	  while (!feof(fp) && i<10)
      {
    	fscanf(fp, "%d %f %f %f %f\n", &id, &x0, &y0, &x1, &y1);
		d = new Entry();
    	d->son = id;
    	d->bounces[0] = x0;
    	d->bounces[1] = x1;
    	d->bounces[2] = y0;
    	d->bounces[3] = y1;
		
		rt->delete_entry(d);
		
		delete d;
		i++;
      }
    }

	fclose(fp);
}





void main(int argc, char* argv[])
{
	RTreeCmdIntrpr * cmd_intr = new RTreeCmdIntrpr();

	cmd_intr -> run();

	delete cmd_intr;
}
