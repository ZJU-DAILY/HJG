#ifndef __RTNODE
#define __RTNODE
//------------------------------------------------------------
#include "../func/gendef.h"
//------------------------------------------------------------
class SortedLinList;
class Entry;
class RTree;
//------------------------------------------------------------
class RTNode
{
public:
    RTree *my_tree;                     // pointer to R-tree
    int dimension;
    bool dirty;                         // TRUE, if node has to be written

    Entry *entries;                     // array of entries
    int capacity;                       // max. # of entries
    int block;                          // disc block
    char level;                         // level of the node in the tree (0 means leaf)

    int num_entries;                    // # of used entries
    int get_num_of_data();              // returns number of data entries

    void read_from_buffer(char *buffer);// reads data from buffer
    void write_to_buffer(char *buffer); // writes data to buffer

    bool is_data_node() { return (level==0) ? TRUE : FALSE ;};

    float *get_mbr();                   // returns mbr enclosing whole page
    void print();                       // prints rectangles

    int split(float **mbr, int **distribution);
                                        // splits an Array of mbr's into 2
                                        // and returns in distribution
                                        // which *m mbr's are to be
                                        // moved

    void rangeQuery(float *mbr, SortedLinList *res);

    R_OVERFLOW insert(Entry *d, RTNode **sn);
                                        // inserts d recursively, if there
                                        // occurs a split, FALSE will be
                                        // returned and in sn a
                                        // pointer to the new node
	R_DELETE delete_entry(Entry *e);
	bool FindLeaf(Entry *e);

    RTNode(RTree *rt);
    RTNode(RTree *rt, int _block);
    virtual ~RTNode();

    void enter(Entry *de);              // inserts new entry

    void split(RTNode *sn);             // splits directory page to *this and sn

    int choose_subtree(float *brm);     // chooses best subtree for insertion
};

#endif